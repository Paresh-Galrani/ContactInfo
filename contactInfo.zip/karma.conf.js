module.exports = function (config) {
    config.set({
        files: ['./tests/tests.js'],
         frameworks: ['jasmine']
    })



}