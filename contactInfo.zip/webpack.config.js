var HtmlWebpackPlugin = require('html-webpack-plugin')
var webpack = require('webpack')
var ExtractTextPlugin = require('extract-text-webpack-plugin')
var StyleCSS = new ExtractTextPlugin("[name].css")
var VendorCSS = new ExtractTextPlugin("vendor.css")

module.exports = {
    entry: "./app/app.module.ts",
    output: { filename: "./bundle.js" },
    resolve: {
        extensions: ['.js', '.jsx', '.ts', '.tsx'],
        modules: ['node_modules']
    },
    module: {
        rules: [{
            test: /\.ts?$/,
            exclude: [/node_modules/, /typings/, /imed_modules/],
            use: [{
                loader: "ng-annotate-loader"
            }, {
                loader: "awesome-typescript-loader",
                options: {
                    silent: true
                }
            }
            ]
        },
        {
            test: /\.css?$/,
            loader: ExtractTextPlugin.extract({ fallback: 'style-loader', use: 'css-loader' })
        },
        {
            test: /\.html$/,
            use: [{
                loader: 'html-loader',
                options: {
                    minimize: true
                }
            }]
        },
        {
            test: /\.(png|jpe?g|gif|svg|woff|woff2|ttf|eot|ico)(\?.*)?$/,
            loader: 'file-loader?name=./assets/[name].[hash].[ext]'
        }]
    },
    plugins: [
        new ExtractTextPlugin("vendor.css"),
        new HtmlWebpackPlugin({
            title: 'ContactInfo',
            filename: 'index.html',
            template: './app/index.html'
        }),
        new webpack.ProvidePlugin({
            $: "jquery",
            jQuery: "jquery",
            "window.jQuery": "jquery"
        })
    ],
    devServer: {
        host: 'localhost',
        port: 3002
    }
}