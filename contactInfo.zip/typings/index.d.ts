declare global {
    const angular:  ng.IAngularStatic ;
}

export {};