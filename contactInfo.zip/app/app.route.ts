import { UrlRouterProvider } from "@uirouter/angularjs/lib";

/* @ngInject */
export let appConfig = ($urlRouterProvider: UrlRouterProvider) => {
    $urlRouterProvider.otherwise('/dashboard')
}