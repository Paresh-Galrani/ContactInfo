
/*  @ngInject */
export class IndexDBService {
    public static id: string = 'indexDbService';
    indexedDB: IDBFactory;
    db: IDBDatabase = null;
    constructor(public $window: ng.IWindowService, public $q: ng.IQService) {
        this.indexedDB = this.$window.indexedDB;
    }

    open = (): ng.IPromise<any> => {
        let deferred = this.$q.defer();
        let request = this.indexedDB.open('contactInfo', 1);

        request.onupgradeneeded = () => {
            this.db = request.result;
            request.transaction.onerror = (<any>this.indexedDB).onerror;
            if (this.db.objectStoreNames.contains('contacts')) {
                this.db.deleteObjectStore('contacts');
            }
            let store = this.db.createObjectStore('contacts', { keyPath: 'id'});
            store.createIndex("emailId", "emailId", { unique: true });
            store.createIndex("id", "id", { unique: true });
        }

        request.onsuccess = () => {
            this.db = request.result;
            deferred.resolve();
        }

        request.onerror = function () {
            deferred.reject();
        };

        return deferred.promise;
    }
}