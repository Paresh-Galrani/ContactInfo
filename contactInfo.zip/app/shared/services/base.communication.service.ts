
/* @ngInject */
export class BaseCommunicationService {

    public static id: string = 'baseCommunicationService';
    constructor(private $http: ng.IHttpService) {

    }
    get<T>(url: string): ng.IHttpPromise<T> {
        return this.$http.get(url);
    }

    post<T>(url: string, data: any): any {
        return this.$http.post(url, data);
    }
    
}