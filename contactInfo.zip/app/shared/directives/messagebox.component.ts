/* @ngInject */
export class MessageBoxComponent {
    public static id: string = 'messageBox';
    public controllerAs : string = 'viewController';
    public template : string = require('./messagebox.component.html');
    bindings: any = {
        messageConfig: '<'
    }
    public static instance = () => {
        return new MessageBoxComponent();
    }
}