/* @ngInject */
export class UpdateContactComponent  {
    public static id: string = 'updateContact';
    public template: string = require('./update.contact.component.html');
    public controllerAs: string = 'viewController'; 
    public bindings: any = {
        contactInfo: '=',
        onSubmit: '&'
    }

    public static instance = ()  => {
        return new UpdateContactComponent();
    }
}