
export enum MessageType {
    SUCCESS,
    ERROR,
    INFO

}
export class MessageConfig {
    message: string;
    messageType: MessageType;
    constructor(msg: string, typ: MessageType) {
        this.message = msg;
        this.messageType = typ;
    }
}