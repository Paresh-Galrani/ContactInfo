/* @ngInject */
export class StatusDisplayFilter {
    public static id: string = 'statusDisplayFilter';
    public static instance = () => {
        let statusDisplayFilter = () => {
            let filter = function (self: boolean): string {
                if (self === true)
                    return 'Active';
                return 'InActive';
            }
            return filter;
        }
        return statusDisplayFilter;
    }
}