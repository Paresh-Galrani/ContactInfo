import { StatusDisplayFilter } from "./filters/status.display.filter";
import { UpdateContactComponent } from "./directives/update.contact.component";
import { BaseCommunicationService } from "./services/base.communication.service";
import { IndexDBService } from "./services/indexDB.service";
import { MessageBoxComponent } from "./directives/messagebox.component";

export let sharedModule: string = 'sharedModule';
angular.module(sharedModule, [])
    .filter(StatusDisplayFilter.id, StatusDisplayFilter.instance())
    .component(UpdateContactComponent.id, UpdateContactComponent.instance())
    .component(MessageBoxComponent.id, MessageBoxComponent.instance())
    .service(IndexDBService.id, IndexDBService)