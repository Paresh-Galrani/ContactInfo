/// <reference path="../typings/index.d.ts" />
import * as angular from 'angular';
import '../node_modules/bootstrap/dist/css/bootstrap.css';
import './app.css';

import 'jquery';
import 'bootstrap';
import '@uirouter/angularjs';

import { contactInfoModule } from './contactInfo/contactInfo.module';
import { appConfig } from "./app.route";
import { sharedModule } from "./shared/shared.module";
angular.module('root', [
    'ui.router',
    contactInfoModule,
    sharedModule
])
    .config(appConfig);