

import { ContactInfo } from "./contactInfo.model";
import { BaseCommunicationService } from "../shared/services/base.communication.service";
import { ContactInfoDBService } from "./contactInfo.db.service";

/* @ngInject */
export class ContactInfoService extends BaseCommunicationService {
    public static id: string = 'contactInfoService';
    constructor($http: ng.IHttpService, private $q: ng.IQService, private contactInfoDBService: ContactInfoDBService) {
        super($http); //Not useful right now
    }
    getContact = (id: number): ng.IPromise<ContactInfo> => {
        let deferred: ng.IDeferred<ContactInfo> = this.$q.defer();
        this.contactInfoDBService.open().then(() => {
            this.contactInfoDBService.getContacts().then((res: Array<ContactInfo>) => {
                let filteredContacts = res.filter((t) => { return t.id == id });
                if (filteredContacts && filteredContacts.length > 0)
                    deferred.resolve(filteredContacts[0]);
                else
                    deferred.resolve(null);
            })
        }).catch((err)=>{
            deferred.reject('Something went wrong ::' + err );
        });

        return deferred.promise;
    }
}