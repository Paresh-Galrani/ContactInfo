import { IndexDBService } from "../shared/services/indexDB.service";
import { ContactInfo } from "./contactInfo.model";

/*@ngInject */
export class ContactInfoDBService extends IndexDBService {
    public static id: string = 'contactInfoDBService';
    lastIndex: number = 0;
    constructor($window: ng.IWindowService, $q: ng.IQService) {
        super($window, $q)
    }

    getContacts = (): ng.IPromise<any> => {
        let deferred = this.$q.defer();
        if (!this.db)
            deferred.reject('DB not yet open');
        else {
            let trans: IDBTransaction = this.db.transaction(['contacts'], 'readwrite');
            let objStore: IDBObjectStore = trans.objectStore('contacts');
            let contacts = [];
            let keyRange: IDBKeyRange = IDBKeyRange.lowerBound(0);
            let cursorRequest: IDBRequest = objStore.openCursor(keyRange);

            cursorRequest.onsuccess = () => {
                let result = cursorRequest.result;
                if (!result)
                    deferred.resolve(contacts);
                else {
                    contacts.push(result.value)
                    if (result.value.id > this.lastIndex)
                        this.lastIndex = result.value.id;
                    result.continue();
                }
            }
            cursorRequest.onerror = function (e: any) {
                console.log(e.value);
                deferred.reject('Something went wrong!!!');
            };
            return deferred.promise;
        }
    }

    saveContact = (contact: ContactInfo): ng.IPromise<any> => {
        let deferred = this.$q.defer();
        if (this.db === null) {
            deferred.reject('IndexDB is not opened yet!');
        }
        else {
            let trans: IDBTransaction = this.db.transaction(['contacts'], 'readwrite');
            let store: IDBObjectStore = trans.objectStore('contacts');
            this.lastIndex++;
            let request: IDBRequest;
            if (!contact.id)
                request = store.put({
                    'id': this.lastIndex,
                    'emailId': contact.emailId,
                    'firstName': contact.firstName,
                    'lastName': contact.lastName,
                    'phoneNo': contact.phoneNo,
                    'isActive': true,
                });
            else
                request = store.put(contact);

            request.onsuccess = function (e) {
                deferred.resolve();
            };
            request.onerror = function (e: any) {
                console.log(e.value);
                deferred.reject('Contact couldnt be added!');
            };
        }
        return deferred.promise;
    };

    deleteContact = (id: number): ng.IPromise<any> => {
        let deferred = this.$q.defer();

        if (!this.db)
            deferred.reject('DB not yet open');
        else {
            let trans: IDBTransaction = this.db.transaction(['contacts'], 'readwrite');
            let store: IDBObjectStore = trans.objectStore('contacts');
            let request: IDBRequest = store.delete(id);
            request.onsuccess = () => {
                deferred.resolve();
            }
            request.onerror = () => {
                console.log(request.result);
                deferred.reject('Item couldnt be deleted');
            }
        }
        return deferred.promise;
    }

}