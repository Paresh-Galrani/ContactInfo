export class ContactInfo {
    id: number;
    firstName: string;
    lastName: string;
    emailId: string;
    phoneNo: string;
    isActive: boolean;
}