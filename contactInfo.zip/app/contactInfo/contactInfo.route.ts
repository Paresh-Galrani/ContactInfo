import { StateProvider } from "@uirouter/angularjs/lib";
import { DashboardController } from "./dashboard/dashboard.controller";
import { AddContactInfoController } from "./add/add.contactInfo.controller";
import { UpdateContactInfoController } from "./update/update.contactInfo.controller";

/* @ngInject */
export let contactInfoRoute = ($stateProvider: StateProvider) => {
    $stateProvider
        .state('dashboard', {
            url: '/dashboard',
            template: require('./dashboard/dashboard.view.html'),
            controller: DashboardController,
            controllerAs: DashboardController.alias
        })
        .state('addcontact', {
            url: '/contactinfo/add',
            template: require('./add/add.contactInfo.view.html'),
            controller: AddContactInfoController,
            controllerAs: AddContactInfoController.alias
        })
        .state('updatecontact', {
            url: '/contactinfo/update/:id',
            template: require('./update/update.contactInfo.view.html'),
            controller: UpdateContactInfoController,
            controllerAs: UpdateContactInfoController.alias
        })
}