
import { ContactInfoDBService } from "../contactInfo.db.service";
import { ContactInfo } from "../contactInfo.model";
import { MessageConfig, MessageType } from "../../shared/models/messageconfig.model";

/* @ngInject */
export class AddContactInfoController {
    public static id: string = 'addContactInfoController';
    public static alias: string = 'viewController';
    contactInfo: ContactInfo;
    messageConfig: MessageConfig;
    constructor(private contactInfoDBService: ContactInfoDBService) {

    }
    onAdd = () => {
        if (this.contactInfo)
            this.contactInfoDBService.open().then(() => {
                this.contactInfoDBService.saveContact(this.contactInfo).then((res) => {
                    this.messageConfig = new MessageConfig('Contact Added successfully', MessageType.SUCCESS);
                }).catch((err) => {
                    this.messageConfig = new MessageConfig('Something went wrong. Contact not saved', MessageType.ERROR);
                });
            });
    }
}