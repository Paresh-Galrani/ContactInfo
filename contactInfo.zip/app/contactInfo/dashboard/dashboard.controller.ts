import { ContactInfo } from "../contactInfo.model";
import { ContactInfoService } from "../contactInfo.service";
import { ContactInfoDBService } from "../contactInfo.db.service";
import { MessageConfig, MessageType } from "../../shared/models/messageconfig.model";

export class DashboardController {
    static id: string = 'dashboardController';
    static alias: string = 'viewController';
    contacts: Array<ContactInfo>;
    messageConfig: MessageConfig;

    /* @ngInject */
    constructor(private contactInfoDBService: ContactInfoDBService) {
        this.initiateData();
    }

    initiateData = () => {
        this.contactInfoDBService.open().then(() => {
            this.contactInfoDBService.getContacts().then((res: ContactInfo[]) => {
                this.contacts = res;
            }).catch((err) => {
                console.dir(err);
            });
        });
    }

    toggleContactStatus = (contact: ContactInfo) => {
        this.contactInfoDBService.open().then(() => {
            contact.isActive = !contact.isActive;
            this.contactInfoDBService.saveContact(contact).then(() => {
                this.messageConfig = new MessageConfig('Status changed successfully', MessageType.SUCCESS);
            }).catch((err) => {
                this.messageConfig = new MessageConfig('Something went wrong. Contact not change status', MessageType.ERROR);
            });
        });
    }
}