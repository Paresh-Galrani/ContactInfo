
import './contactInfo.css'
import { contactInfoRoute } from "./contactInfo.route";
import { ContactInfoService } from "./contactInfo.service";
import { ContactInfoDBService } from "./contactInfo.db.service";
export var contactInfoModule: string = 'contactInfoModule';
angular.module(contactInfoModule, [])
    .config(contactInfoRoute)
    .service(ContactInfoService.id, ContactInfoService)
    .service(ContactInfoDBService.id, ContactInfoDBService)
