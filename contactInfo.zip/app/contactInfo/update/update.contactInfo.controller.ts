
import { StateParams } from "@uirouter/angularjs/lib";
import { ContactInfo } from "../contactInfo.model";
import { ContactInfoDBService } from "../contactInfo.db.service";
import { MessageConfig, MessageType } from "../../shared/models/messageconfig.model";
import { ContactInfoService } from "../contactInfo.service";

/* @ngInject */
export class UpdateContactInfoController {
    public static id: string = 'updateContactInfoController';
    public static alias: string = 'viewController';
    contactInfo: ContactInfo;
    messageConfig: MessageConfig;

    constructor(private $stateParams: StateParams, private contactInfoService: ContactInfoService, private contactInfoDBService: ContactInfoDBService) {
        this.getContact($stateParams.id);
    }

    getContact = (id: number) => {
        this.contactInfoService.getContact(id).then((res) => {
            if (res && res.id > 0) {
                this.contactInfo = res;
            }
            else {
                this.messageConfig = new MessageConfig('Record not found', MessageType.ERROR);
            }
        });
    }
    onUpdate = () => {
        this.contactInfoDBService.open().then(() => {
            this.contactInfoDBService.saveContact(this.contactInfo).then(() => {
                this.messageConfig = new MessageConfig('Contact Updated successfully', MessageType.SUCCESS);
            }).catch(() => {
                this.messageConfig = new MessageConfig('Something went wrong. Contact not updated', MessageType.ERROR);
            })
        });
    }
}